__author__ = "Tsuyoshi Hombashi"
__copyright__ = f"Copyright 2016, {__author__}"
__license__ = "MIT License"
__version__ = "3.2.0"
__maintainer__ = __author__
__email__ = "tsuyoshi.hombashi@gmail.com"
