class PyreadrError(Exception):
    pass
    
class LibrdataError(Exception):
    pass
